programa {
  funcao inicio() {
    real conta, pessoas, divisaoConta

    escreva("Quantas pessoas iram dividir a conta do bar?\n")
    leia(pessoas)

    escreva("Qual é o valor da conta?\n")
    leia(conta)

    divisaoConta = conta / pessoas

    escreva("Todos deveram dar  igualmente o valor de R$", divisaoConta, " para pagar a conta de R$", conta)
  }
}
