programa {
  funcao inicio() {
    real km, litrosKm, litrosTotais

    escreva("Quantos km seram percorridos?\n")
    leia(km)

  escreva("Um litro de gasólina é consumido em quantos km?\n")
  leia(litrosKm)

  litrosTotais = km / litrosKm

  escreva("Para completar o percurso de ", km, " será necessário ", litrosTotais, " litros.")
  }
}
