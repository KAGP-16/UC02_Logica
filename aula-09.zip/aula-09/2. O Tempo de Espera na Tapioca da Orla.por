programa {
  funcao inicio() {
    real minutosTapioca, pessoas, tempoEspera

    escreva("Quantas pessoas estão na fila a frente Sandra?\n")
    leia(pessoas)

    escreva("Em quantos minutos uma tapioca é feita?\n")
    leia(minutosTapioca)

    tempoEspera = minutosTapioca * pessoas

    escreva("Sandra deve esperar ", tempoEspera, " minutos para chegar na sua vez.")
  }
}
