programa {
  funcao inicio() {
    real golsFeitos, golsSofridos, saldoFinal

    escreva("Quantos gols o time fez durante o campeonato?\n")
    leia(golsFeitos)

    escreva("Quantos gols ele sofreu durante o campeonato?\n")
    leia(golsSofridos)

    saldoFinal = golsFeitos - golsSofridos

    escreva("O time acabou com um saldo final de ", saldoFinal, " gols.")
  }
}
