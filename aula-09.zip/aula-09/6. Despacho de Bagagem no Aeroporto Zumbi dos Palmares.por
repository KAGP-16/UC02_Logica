programa {
  funcao inicio() {
    real quilos, limite, pesoLivre

    escreva("A mala pesa quantos quilos?\n")
    leia(quilos)

    escreva("Qual é o limite de peso?\n")
    leia(limite)

    pesoLivre = limite - quilos

    escreva("O peso livre é de ", pesoLivre, " quilos.")
  }
}
