programa {
  funcao inicio() {
    real horas, telhas, horaProducao

    escreva("Foram quantas horas de produção?\n")
    leia(horas)

    escreva("Quantas telhas foram produzidas?\n")
    leia(telhas)

    horaProducao = telhas / horas

    escreva("Foram produzidas ", horaProducao, " telhas por hora.")
  }
}
