programa {
  funcao inicio() {
    real precoJangada, pessoas, divisaoValor

    escreva("Quantas pessoas iram para o passeio de jangada?\n")
    leia(pessoas)

    escreva("Qual é o preço do passeio?\n")
    leia(precoJangada)

    divisaoValor = precoJangada / pessoas

    escreva("Cada um terá de pagar o valor correspondente de R$", divisaoValor)
  }
}
