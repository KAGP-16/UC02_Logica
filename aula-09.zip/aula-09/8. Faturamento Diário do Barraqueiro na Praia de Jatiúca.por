programa {
  funcao inicio() {
    real valorCoco, cocos, ganhoBruto

  escreva("Qual é o valor do coco?\n")
  leia(valorCoco)

  escreva("Quantos cocos foram vendidos no dia?\n")
  leia(cocos)

  ganhoBruto = valorCoco * cocos
  escreva("No tatal, o ganho com a venda dos cocos foi de R$", ganhoBruto)
  }
}
