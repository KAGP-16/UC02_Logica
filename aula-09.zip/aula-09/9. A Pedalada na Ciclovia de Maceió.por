programa {
  funcao inicio() {
    real km, minnutos, kmMinutos

    escreva("Quantos minutos levaram para chegar ao final do percurso?\n")
    leia(minnutos)
    escreva("São quantos km ao todo?\n")
    leia(km)

    kmMinutos = km / minnutos

    escreva("A média é de ", kmMinutos, " km/min.")
  }
}
