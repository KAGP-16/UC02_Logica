programa {
  funcao inicio() {
    real valorPassaporte, valorcedula, trocoFinal

    escreva("Qual é o valor do passsaporte de acesso?\n")
    leia(valorPassaporte)

    escreva("Qual é o valor da cédula dada pela mãe de Pedrinho?\n")
    leia(valorcedula)

    trocoFinal = valorcedula - valorPassaporte

    escreva("O troco de Pedrinho será de R$", trocoFinal)
  }
}
