programa{
funcao inicio(){
real conta, pessoas, divisaoDeValores

escreva("Qual é o valor da conta?\n")
leia(conta)

escreva("Quantas pessoas foram jantar?\n")
leia(pessoas)

divisaoDeValores = conta / pessoas

escreva("Cada um terá de pagar R$", divisaoDeValores, ".")

    }
}