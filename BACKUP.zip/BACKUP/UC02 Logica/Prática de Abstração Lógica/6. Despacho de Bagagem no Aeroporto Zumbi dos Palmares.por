programa {
  funcao inicio() {
    real pesoDaBagagem, limite, pesoLivre 
    escreva("Quantos quilos a mala pesa?\n")
    leia(pesoDaBagagem)
    escreva("Qual é o llimte de peso?\n")
    leia(limite)
    pesoLivre = limite - pesoDaBagagem
    
    escreva("Sobraram ", pesoLivre, " quilos livres.")
  }
}
