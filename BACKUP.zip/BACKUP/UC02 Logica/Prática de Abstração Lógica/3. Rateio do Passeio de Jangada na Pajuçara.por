programa{
funcao inicio(){
real precoDaPassagem, pessoas, divisaoDeValores

escreva("Qual é o preço da passagem?\n")
leia(precoDaPassagem)

escreva("Quantas pessoas irão ao passeio?\n")
leia(pessoas)

divisaoDeValores = precoDaPassagem / pessoas

escreva("Cada um terá de pagar R$", divisaoDeValores, ".")

    }
}