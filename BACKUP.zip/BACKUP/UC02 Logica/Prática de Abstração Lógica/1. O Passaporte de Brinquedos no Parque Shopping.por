programa {
  funcao inicio() {
    real ingresso, dinheiro, troco 
    escreva("Qual é o valor do ingresso?\n")
    leia(ingresso)
    escreva("Quantos reais a mãe Pedrinho deu a ele?\n")
    leia(dinheiro)
    troco = dinheiro - ingresso
    
    escreva("Se o valor do ingresso é de R$", ingresso, " e a mãe do Pedrinho lhe deu R$", dinheiro, "\nPedrinho irá receber R$", troco, " de troco.")
  }
}
