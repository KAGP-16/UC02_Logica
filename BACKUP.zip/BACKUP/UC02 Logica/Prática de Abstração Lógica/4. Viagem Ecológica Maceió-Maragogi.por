programa{
    funcao inicio(){    
        real combustivel, litrosPorKm, distancia, calculoTotal

        escreva("Um litro é equivalente a quantos Km?\n")
        leia(litrosPorKm)

        escreva("Qual é a distãncia a ser percorrida?\n")
        leia(distancia)

        calculoTotal = distancia / litrosPorKm 

        escreva("Serão necessários ", calculoTotal, " litros para completar todo percurso.")
    }
}