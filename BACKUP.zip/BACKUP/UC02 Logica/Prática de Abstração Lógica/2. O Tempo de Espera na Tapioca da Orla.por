programa{
    funcao inicio(){
        real quantidade, minutos, resultado

    escreva("Quantas tapiocas serão feitas?\n")
    leia(quantidade)
    escreva("Quantos minutos leva para cada tapioca ficar pronta?\n")
    leia(minutos)

    resultado = quantidade * minutos

    escreva("Levará em torno de ", resultado, " minutos para as tapiocas ficarem prontas.")

    }
}