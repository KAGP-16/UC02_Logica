programa {
  funcao inicio() {
    
    real peso, altura, imc
  

escreva("Qual é a sua altura?\n")
leia("altura")
escreva("Qual é o seu peso?\n")
leia(peso)

imc = peso / (altura * altura)
se(peso == 0 e altura == 0){

escreva("Erro: Peso e altura devem ser maiores que zero!")
retorne
}

se(imc == 18.5){

escreva("Abaixo do peso.")
}
se(imc == 18.5 <= 24.9){

escreva("Peso normal (Adequado).")
}
se(imc == 25 <= 29.9){

escreva("Sobrepeso.")
}
se(imc == 30 <= 34.9){

escreva("Obesidade Grau I.")
}
se(imc == 35 <= 39.9){

escreva("Obesidade Grau II.")
}
se(imc >= 40){

escreva("Obesidade Grau III (Mórbida).")
}
  }
}
