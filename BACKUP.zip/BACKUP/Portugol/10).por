programa {
  funcao inicio() {
    real salgado, suco,somaTotal
    escreva("Qual é a quantidade de calorias do salgado?\n")
    leia(salgado)

    escreva("Qual é a quantidade de calorias do suco?\n")
    leia(suco)

somaTotal = salgado + suco

escreva("A soma total das calorias é de: ", somaTotal)
  }
}
