programa {
  funcao inicio() {
    real arquibancadas, cadeirasEspeciais, totaldeTorcedores
  escreva("O número de torcedores que sentaram nas arquibancadas é de: ")
  leia(arquibancadas)

  escreva("\nJá o númer de torcedores nas cadeiras especiais é de: ")
  leia(cadeirasEspeciais)

  totaldeTorcedores = arquibancadas + cadeirasEspeciais
  escreva("O total de torcedores será de: ", totaldeTorcedores)


}
}
