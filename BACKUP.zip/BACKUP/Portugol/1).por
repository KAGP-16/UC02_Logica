programa{
  funcao inicio(){

    real saldoAtual, valordaPassagem, saldoFinal
  escreva("Seu saldo atual é: ")
  leia(saldoAtual)

  escreva("\nO valor da passagem é: ")
  leia(valordaPassagem)

 saldoFinal = saldoAtual - valordaPassagem
  escreva("\nSeu saldo final será de: ", saldoFinal)
 






  }

}
