programa {
  funcao inicio() {
    
    real ml = 100, custoMedio = 0.40, total

    escreva("O motorista Travis está transportando uma familia italiana pela AL-101 Sul, percorrendo uma distância de 10km.", "\n")

    escreva("Gastando em média ", custoMedio, " centavos a cada cem metros percorrido.", "\n")

  total = custoMedio * ml / 4
    escreva("Ao todo gastando R$", total, " em média por quilomêtro.")
  }
}
