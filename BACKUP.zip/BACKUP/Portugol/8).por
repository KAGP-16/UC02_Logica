programa {
  funcao inicio() {
    
    real ida = 400, volta = 400 , idaEvolta = ida + volta
    
escreva("Carlinhos percorre todo dia ", ida,  " metros da Pajuçara até Cruz das Almas, onde fica o seu trabalho.")
 
    escreva("\nNA volta para casa, Carlinhos faz o mesmo percurso de ", volta, " metros\n")

       escreva("\nAo todo, Carlinhos terá andado ", idaEvolta, " metros de distanc no final do dia.")
  }
}
