programa {
  funcao inicio() {
    
    real metros, velocidade, minutos
    
escreva("Qual a distancia que Mariana deve percorrer?\n")
leia(metros)
 
    escreva("Qual a velocidade média que Mariana consegue alcançar?\n")
    leia(velocidade)


minutos = metros / velocidade

       escreva("\nMaria levara ", minutos, " minutos para chegar ao seu destino?")
  }
}
