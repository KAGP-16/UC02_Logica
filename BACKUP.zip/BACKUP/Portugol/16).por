programa {
  funcao inicio() {
    real poupanca, total
    escreva("Quantos reais foram guardados em cada semana?\n")
    leia(poupanca)

  total = poupanca * 4
    escreva("no fim do mês, ", total, " foram guardados.")
  }
}
