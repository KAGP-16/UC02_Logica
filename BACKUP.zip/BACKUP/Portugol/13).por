programa {
  funcao inicio() {
    real preco, conta

    escreva("Quanto custa o Açaí?\n")
    leia(preco)

    conta = preco / 3
    escreva("Ao todo, eles devem pagar R$", conta, " cada.")
  }
}
