programa {
  funcao inicio() {
    real vitorias, totaldePontos

    escreva("Quantas vitorias o seu time conseguiu?\n")
    leia(vitorias)

    totaldePontos = vitorias * 3
    escreva("Ao todo, o time conseguiu ", totaldePontos, " pontos.")
  }
}
