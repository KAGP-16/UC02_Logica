programa {
  funcao inicio() {
    real cocada = 3.0, quantidade, valorBruto

    escreva("Quantas cocadas foram vendidas no dia?\n")
    leia(quantidade)

   valorBruto = cocada * quantidade
   
    escreva("Dona Maria ao todo vendeu ", quantidade, " cocadas, conseguindo R$", valorBruto, " no fim do dia.")


    
  }
}
