programa {
  funcao inicio() {
    real ingresso, alunos, meiaEntrada
    escreva("Quantos alunos irão ao cinema?\n")
    leia(alunos) 

    escreva("Quanto custa o ingresso?\n")
    leia(ingresso)
  
    meiaEntrada = ingresso / 2 * alunos
    escreva("Os alunos devem pagar ao todo R$", meiaEntrada, ".")
  }
}
