programa {
  funcao inicio() {
    
real lucroBruto, custo, lucroLiquido

    escreva("Qual é o Lucro Bruto?\n")
    leia(lucroBruto)

escreva("Qual o valor dos insumos usados?\n")
    leia(custo)

    lucroLiquido = lucroBruto - custo

    escreva("Uma noite de vendas rendeu em lucro liquido de R$", lucroLiquido, ".")
 

  }
}
