programa {
  funcao inicio() {
    real passagem, viagem, custoDiario, custoMensal
    
    escreva("A passagem de ônibus que Albert deve pagar para viajar é de R$")
    leia(passagem)
 
 custoDiario = passagem + passagem
 escreva("\nDurante vinte dias, albert paga duas passagens de ida e volta. Seu custo diario sendo de: R$", custoDiario)

    
    
    custoMensal = custoDiario * 20
    escreva("\nNo final do mês, Albert terá gasto de passagem exatos: R$", custoMensal)

    
  }
}
