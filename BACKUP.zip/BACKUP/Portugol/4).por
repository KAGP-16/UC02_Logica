programa {
  
  
  funcao inicio() {
  
  }
}
