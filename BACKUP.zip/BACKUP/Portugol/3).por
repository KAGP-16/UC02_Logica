programa {
  funcao inicio() {
    real custodaPassagem, valorTotal

    escreva("O uma viagem de Jangada custo R$")
    leia(custodaPassagem) 
  
    valorTotal = custodaPassagem / 4
    escreva("Marty, Alex, Gloria e Melman devem pagar R$", valorTotal, " cada.")


  }
}

