programa {
  funcao inicio() {
    //real sabor = (Morango = 46), (Baunilha = 34), (Chocolate = 25), (Flocos = 19)
    cadeia sabor
    real valor, total, desconto = 0.4
    escreva("A sorveteria 'Ice Maiden' iniciou uma campanha de 'Salve o Mundo' ", "\nonde todo retulizavel é equivalente a um percentual de desconto de 40%,", "\n",
    "para cada pote sorvete comprado.\n")


    escreva("\nTemos os sabores: Morango, Baunilha, chocolate e Flocos.\nQual desses sabores você gostaria?\n")
    leia(sabor)

    escolha(sabor) {
      caso "Morango":
        valor = 46
      pare
      caso "Baunilha":
        valor = 34
      pare
      caso "Chocolate":
        valor = 25
      pare
      caso "Flocos":
        valor = 20
      pare
      caso contrario: 
        retorne escreva("Infelizmente não temos este sabor")
    }

    total = valor * desconto

    escreva(total)

  }
}
