programa {
  funcao inicio() {
    logico admin = verdadeiro
    logico permissaoDeExcluirUsuario = verdadeiro

    se(admin ou permissaoDeExcluirUsuario){
      retorne escreva("Usuario excluido com sucesso!")

    }

    escreva("O usuario não é administrativo ou não tem permissão de excluir!")
  }
}
