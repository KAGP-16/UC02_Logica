programa {
  funcao inicio() {
    cadeia email = "meu.email@email.com"
    cadeia senha = "123456"
    escreva("Informe o seu email: ")
    leia(email)
    escreva("Informe a sua senha super secreta: ")
    leia(senha)
      se(email == "meu.email@email.com" e senha == "123456"){
           retorne escreva("Acesso liberado!")
      }
      escreva("Acesso negado!")
     
  }
}
